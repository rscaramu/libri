# Esempi di codice

Tutti i programmi e le unit del libro, un file per ciascuno, nell’ordine in cui compaiono nel testo. Ogni file è stato compilato e, dove ha senso, eseguito con Free Pascal 3.2.2 e Lazarus 3.0 durante la scrittura del libro.

## Come usarli

- **Programmi da console** (`program …`): `fpc -Mobjfpc -Sh nomefile.pas` e poi `./nomefile` (su Windows `nomefile.exe`). Se un programma legge dall’input, l’intestazione del file indica i valori usati nel libro.
- **Unit** (`unit …`): vanno messe nella stessa cartella del programma che le usa; il compilatore le trova da solo.
- **Unit LCL** (segnalate nell’intestazione): sono i form dei capitoli 20–34; vanno inserite in un progetto Lazarus, dove il file `.lfm` con i componenti si costruisce nel progettista secondo le indicazioni del capitolo. I capitoli 27 e 32 richiedono il pacchetto `SQLDBLaz`, il capitolo 33 il pacchetto `SynEdit`.
- Su Linux, per SQLite serve `libsqlite3-dev`; per HTTPS le librerie OpenSSL.

## Indice per capitolo

- `cap01/` — Capitolo 1 — Perché Free Pascal e Lazarus (3 file)
- `cap02/` — Capitolo 2 — Installazione e primo programma (3 file)
- `cap03/` — Capitolo 3 — Variabili, tipi semplici e costanti (8 file)
- `cap04/` — Capitolo 4 — Operatori ed espressioni (7 file)
- `cap05/` — Capitolo 5 — Strutture di controllo (9 file)
- `cap06/` — Capitolo 6 — Procedure e funzioni (9 file)
- `cap07/` — Capitolo 7 — Array e stringhe (9 file)
- `cap08/` — Capitolo 8 — Record, enumerati e insiemi (8 file)
- `cap09/` — Capitolo 9 — Puntatori e memoria dinamica (8 file)
- `cap10/` — Capitolo 10 — Unit e organizzazione del codice (10 file)
- `cap11/` — Capitolo 11 — File e input/output (9 file)
- `cap12/` — Capitolo 12 — Eccezioni e gestione degli errori (8 file)
- `cap13/` — Capitolo 13 — Classi e oggetti (9 file)
- `cap14/` — Capitolo 14 — Ereditarietà e polimorfismo (7 file)
- `cap15/` — Capitolo 15 — Interfacce, proprietà e RTTI (7 file)
- `cap16/` — Capitolo 16 — Generici (7 file)
- `cap17/` — Capitolo 17 — La libreria di runtime: stringhe, date, collezioni (7 file)
- `cap18/` — Capitolo 18 — Funzionalità avanzate del linguaggio (8 file)
- `cap20/` — Capitolo 20 — Form, eventi e componenti (6 file)
- `cap21/` — Capitolo 21 — Controlli standard e layout (6 file)
- `cap22/` — Capitolo 22 — Menu, dialoghi e azioni (4 file)
- `cap23/` — Capitolo 23 — Grafica: TCanvas, TImage, TPaintBox (7 file)
- `cap24/` — Capitolo 24 — Componenti non visuali: timer, liste, frame, data module (8 file)
- `cap25/` — Capitolo 25 — Architettura di un’applicazione LCL (7 file)
- `cap26/` — Capitolo 26 — Database con SQLdb e SQLite (8 file)
- `cap27/` — Capitolo 27 — Controlli data-aware (7 file)
- `cap28/` — Capitolo 28 — JSON, XML e file di configurazione (9 file)
- `cap29/` — Capitolo 29 — Rete: HTTP client e server con fphttp (9 file)
- `cap30/` — Capitolo 30 — Thread, processi e portabilità (8 file)
- `cap31/` — Capitolo 31 — Progetto: gestore di attività da console (4 file)
- `cap32/` — Capitolo 32 — Progetto: rubrica desktop con database (5 file)
- `cap33/` — Capitolo 33 — Progetto: editor di testo con SynEdit (5 file)
- `cap34/` — Capitolo 34 — Progetto: client REST e distribuzione multipiattaforma (4 file)
- `capAppF/` — Appendice F — Soluzioni degli esercizi proposti (67 file)
