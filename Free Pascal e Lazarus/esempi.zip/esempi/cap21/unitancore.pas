{ UnitAncore - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitAncore;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls;

type
  TFormAncore = class(TForm)
    LblTitolo: TLabel;
    EdtTitolo: TEdit;
    MemoTesto: TMemo;
    BtnOk: TButton;
    BtnAnnulla: TButton;
    procedure FormCreate(Sender: TObject);
  end;

var
  FormAncore: TFormAncore;

implementation

{$R *.lfm}

procedure TFormAncore.FormCreate(Sender: TObject);
begin
  LblTitolo.SetBounds(8, 12, 60, 20);
  EdtTitolo.SetBounds(72, 8, Width - 80, 28);
  EdtTitolo.Anchors := [akLeft, akTop, akRight];
  MemoTesto.SetBounds(8, 44, Width - 16, Height - 92);
  MemoTesto.Anchors := [akLeft, akTop, akRight, akBottom];
  BtnAnnulla.SetBounds(Width - 96, Height - 40, 88, 32);
  BtnAnnulla.Anchors := [akRight, akBottom];
  BtnOk.SetBounds(Width - 192, Height - 40, 88, 32);
  BtnOk.Anchors := [akRight, akBottom];
  Constraints.MinWidth := 320;
  Constraints.MinHeight := 200;
end;

end.
