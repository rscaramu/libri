{ UnitElenchi - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitElenchi;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ComCtrls;

type
  TFormElenchi = class(TForm)
    LstNomi: TListBox;
    CmbFiltro: TComboBox;
    TvAlbero: TTreeView;
    LvTabella: TListView;
    procedure FormCreate(Sender: TObject);
    procedure LstNomiSelectionChange(Sender: TObject;
                                     User: Boolean);
  end;

var
  FormElenchi: TFormElenchi;

implementation

{$R *.lfm}

procedure TFormElenchi.FormCreate(Sender: TObject);
var
  Radice, Nodo: TTreeNode;
  Voce: TListItem;
  I: Integer;
begin
  LstNomi.Items.AddObject('Rossi', TObject(PtrInt(1001)));
  LstNomi.Items.AddObject('Bianchi', TObject(PtrInt(1002)));
  CmbFiltro.Items.Add('Tutti');
  CmbFiltro.Items.Add('Attivi');
  CmbFiltro.ItemIndex := 0;

  Radice := TvAlbero.Items.Add(nil, 'Progetti');
  Nodo := TvAlbero.Items.AddChild(Radice, 'Lazarus');
  TvAlbero.Items.AddChild(Nodo, 'unit1.pas');
  TvAlbero.Items.AddChild(Radice, 'Free Pascal');
  Radice.Expand(True);

  LvTabella.ViewStyle := vsReport;
  LvTabella.Columns.Add.Caption := 'Nome';
  LvTabella.Columns.Add.Caption := 'Dimensione';
  LvTabella.Columns[0].Width := 150;
  for I := 1 to 3 do
  begin
    Voce := LvTabella.Items.Add;
    Voce.Caption := Format('file%d.txt', [I]);
    Voce.SubItems.Add(IntToStr(I * 1024));
  end;
end;

procedure TFormElenchi.LstNomiSelectionChange(Sender: TObject;
                                              User: Boolean);
begin
  if LstNomi.ItemIndex >= 0 then
    Caption := Format('%s (id %d)',
      [LstNomi.Items[LstNomi.ItemIndex],
       PtrInt(LstNomi.Items.Objects[LstNomi.ItemIndex])]);
end;

end.
