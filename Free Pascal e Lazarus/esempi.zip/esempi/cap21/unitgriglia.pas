{ UnitGriglia - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitGriglia;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Grids, StdCtrls;

type
  TFormGriglia = class(TForm)
    Griglia: TStringGrid;
    LblTotale: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure GrigliaSetEditText(Sender: TObject;
      ACol, ARow: Integer; const Value: String);
  private
    procedure Ricalcola;
  end;

var
  FormGriglia: TFormGriglia;

implementation

{$R *.lfm}

procedure TFormGriglia.FormCreate(Sender: TObject);
var
  R: Integer;
begin
  Griglia.ColCount := 3;
  Griglia.RowCount := 4;
  Griglia.FixedRows := 1;
  Griglia.FixedCols := 0;
  Griglia.Rows[0].CommaText := 'Articolo,Quantita,Prezzo';
  Griglia.Options := Griglia.Options + [goEditing];
  for R := 1 to 3 do
  begin
    Griglia.Cells[0, R] := 'Articolo ' + IntToStr(R);
    Griglia.Cells[1, R] := IntToStr(R);
    Griglia.Cells[2, R] := '10';
  end;
  Griglia.AutoSizeColumns;
  Ricalcola;
end;

procedure TFormGriglia.GrigliaSetEditText(Sender: TObject;
  ACol, ARow: Integer; const Value: String);
begin
  Ricalcola;
end;

procedure TFormGriglia.Ricalcola;
var
  R: Integer;
  Q, P, Tot: Double;
begin
  Tot := 0;
  for R := 1 to Griglia.RowCount - 1 do
    if TryStrToFloat(Griglia.Cells[1, R], Q) and
       TryStrToFloat(Griglia.Cells[2, R], P) then
      Tot := Tot + Q * P;
  LblTotale.Caption := Format('Totale: %.2f', [Tot]);
end;

end.
