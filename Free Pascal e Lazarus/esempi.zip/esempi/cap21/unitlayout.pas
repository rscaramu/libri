{ UnitLayout - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitLayout;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls;

type
  TFormLayout = class(TForm)
    PnlAlto: TPanel;
    PnlBasso: TPanel;
    LstSinistra: TListBox;
    Divisore: TSplitter;
    MemoCentro: TMemo;
    BtnOk: TButton;
    BtnAnnulla: TButton;
    procedure FormCreate(Sender: TObject);
  end;

var
  FormLayout: TFormLayout;

implementation

{$R *.lfm}

procedure TFormLayout.FormCreate(Sender: TObject);
begin
  { Normalmente si fa nell'Inspector: qui da codice
    per mostrare le proprieta' coinvolte }
  PnlAlto.Align := alTop;
  PnlAlto.Height := 40;
  PnlBasso.Align := alBottom;
  PnlBasso.Height := 48;
  LstSinistra.Align := alLeft;
  LstSinistra.Width := 160;
  Divisore.Align := alLeft;
  MemoCentro.Align := alClient;
  MemoCentro.BorderSpacing.Around := 4;

  BtnOk.Parent := PnlBasso;
  BtnAnnulla.Parent := PnlBasso;
  BtnAnnulla.AnchorSideRight.Control := PnlBasso;
  BtnAnnulla.AnchorSideRight.Side := asrRight;
  BtnAnnulla.Anchors := [akTop, akRight];
  BtnAnnulla.BorderSpacing.Right := 8;
  BtnOk.AnchorSideRight.Control := BtnAnnulla;
  BtnOk.AnchorSideRight.Side := asrLeft;
  BtnOk.Anchors := [akTop, akRight];
  BtnOk.BorderSpacing.Right := 8;
  Constraints.MinWidth := 400;
  Constraints.MinHeight := 300;
end;

end.
