{ UnitSchede - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitSchede;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ComCtrls;

type
  TFormSchede = class(TForm)
    PC: TPageControl;
    BtnNuova: TButton;
    BtnChiudi: TButton;
    procedure BtnNuovaClick(Sender: TObject);
    procedure BtnChiudiClick(Sender: TObject);
  private
    FContatore: Integer;
  end;

var
  FormSchede: TFormSchede;

implementation

{$R *.lfm}

procedure TFormSchede.BtnNuovaClick(Sender: TObject);
var
  Scheda: TTabSheet;
  M: TMemo;
begin
  Inc(FContatore);
  Scheda := TTabSheet.Create(PC);
  Scheda.PageControl := PC;
  Scheda.Caption := 'Documento ' + IntToStr(FContatore);
  M := TMemo.Create(Scheda);
  M.Parent := Scheda;
  M.Align := alClient;
  M.ScrollBars := ssAutoBoth;
  PC.ActivePage := Scheda;
end;

procedure TFormSchede.BtnChiudiClick(Sender: TObject);
begin
  if PC.ActivePage <> nil then
    PC.ActivePage.Free;
end;

end.
