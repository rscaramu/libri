{ UnitSpesa - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitSpesa;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls;

type
  TFormSpesa = class(TForm)
    EdtVoce: TEdit;
    BtnAggiungi: TButton;
    BtnRimuovi: TButton;
    ChkOrdinata: TCheckBox;
    LstSpesa: TListBox;
    procedure BtnAggiungiClick(Sender: TObject);
    procedure BtnRimuoviClick(Sender: TObject);
    procedure ChkOrdinataChange(Sender: TObject);
    procedure EdtVoceKeyPress(Sender: TObject; var Key: Char);
    procedure LstSpesaSelectionChange(Sender: TObject;
                                      User: Boolean);
  end;

var
  FormSpesa: TFormSpesa;

implementation

{$R *.lfm}

procedure TFormSpesa.BtnAggiungiClick(Sender: TObject);
var
  S: String;
begin
  S := Trim(EdtVoce.Text);
  if S = '' then
    Exit;
  if LstSpesa.Items.IndexOf(S) < 0 then
    LstSpesa.Items.Add(S);
  EdtVoce.Clear;
  EdtVoce.SetFocus;
end;

procedure TFormSpesa.EdtVoceKeyPress(Sender: TObject;
                                     var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    BtnAggiungiClick(nil);
  end;
end;

procedure TFormSpesa.BtnRimuoviClick(Sender: TObject);
begin
  if LstSpesa.ItemIndex >= 0 then
    LstSpesa.Items.Delete(LstSpesa.ItemIndex);
  BtnRimuovi.Enabled := LstSpesa.ItemIndex >= 0;
end;

procedure TFormSpesa.ChkOrdinataChange(Sender: TObject);
begin
  LstSpesa.Sorted := ChkOrdinata.Checked;
end;

procedure TFormSpesa.LstSpesaSelectionChange(Sender: TObject;
                                             User: Boolean);
begin
  BtnRimuovi.Enabled := LstSpesa.ItemIndex >= 0;
end;

end.
