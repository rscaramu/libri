{ UnitAzioni - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitAzioni;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ActnList,
  Menus, ComCtrls, Dialogs;

type
  TFormAzioni = class(TForm)
    Azioni: TActionList;
    ActNuovo: TAction;
    ActSalva: TAction;
    ActEsci: TAction;
    MainMenu: TMainMenu;
    MnuFile: TMenuItem;
    MnuNuovo: TMenuItem;
    MnuSalva: TMenuItem;
    MnuEsci: TMenuItem;
    BarraStrumenti: TToolBar;
    TbNuovo: TToolButton;
    TbSalva: TToolButton;
    Memo: TMemo;
    BarraStato: TStatusBar;
    procedure ActEsciExecute(Sender: TObject);
    procedure ActNuovoExecute(Sender: TObject);
    procedure ActSalvaExecute(Sender: TObject);
    procedure ActSalvaUpdate(Sender: TObject);
    procedure MemoChange(Sender: TObject);
  private
    FModificato: Boolean;
  end;

var
  FormAzioni: TFormAzioni;

implementation

{$R *.lfm}

procedure TFormAzioni.ActNuovoExecute(Sender: TObject);
begin
  Memo.Clear;
  FModificato := False;
  BarraStato.SimpleText := 'Nuovo documento';
end;

procedure TFormAzioni.ActSalvaExecute(Sender: TObject);
begin
  Memo.Lines.SaveToFile('documento.txt');
  FModificato := False;
  BarraStato.SimpleText := 'Salvato';
end;

procedure TFormAzioni.ActSalvaUpdate(Sender: TObject);
begin
  (Sender as TAction).Enabled := FModificato;
end;

procedure TFormAzioni.ActEsciExecute(Sender: TObject);
begin
  Close;
end;

procedure TFormAzioni.MemoChange(Sender: TObject);
begin
  FModificato := True;
end;

end.
