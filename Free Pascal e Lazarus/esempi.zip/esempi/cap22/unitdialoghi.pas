{ UnitDialoghi - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitDialoghi;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Dialogs,
  Graphics;

type
  TFormDialoghi = class(TForm)
    Memo: TMemo;
    BtnApri: TButton;
    BtnSalva: TButton;
    BtnCarattere: TButton;
    BtnColore: TButton;
    OpenDialog: TOpenDialog;
    SaveDialog: TSaveDialog;
    FontDialog: TFontDialog;
    ColorDialog: TColorDialog;
    procedure BtnApriClick(Sender: TObject);
    procedure BtnSalvaClick(Sender: TObject);
    procedure BtnCarattereClick(Sender: TObject);
    procedure BtnColoreClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    FNomeFile: String;
  end;

var
  FormDialoghi: TFormDialoghi;

implementation

{$R *.lfm}

procedure TFormDialoghi.FormCreate(Sender: TObject);
begin
  OpenDialog.Filter := 'File di testo|*.txt|Tutti i file|*';
  OpenDialog.Options := OpenDialog.Options +
                        [ofFileMustExist];
  SaveDialog.Filter := OpenDialog.Filter;
  SaveDialog.DefaultExt := 'txt';
  SaveDialog.Options := SaveDialog.Options +
                        [ofOverwritePrompt];
end;

procedure TFormDialoghi.BtnApriClick(Sender: TObject);
begin
  if OpenDialog.Execute then
  begin
    FNomeFile := OpenDialog.FileName;
    Memo.Lines.LoadFromFile(FNomeFile);
    Caption := ExtractFileName(FNomeFile);
  end;
end;

procedure TFormDialoghi.BtnSalvaClick(Sender: TObject);
begin
  SaveDialog.FileName := FNomeFile;
  if SaveDialog.Execute then
  begin
    FNomeFile := SaveDialog.FileName;
    Memo.Lines.SaveToFile(FNomeFile);
    Caption := ExtractFileName(FNomeFile);
  end;
end;

procedure TFormDialoghi.BtnCarattereClick(Sender: TObject);
begin
  FontDialog.Font := Memo.Font;
  if FontDialog.Execute then
    Memo.Font := FontDialog.Font;
end;

procedure TFormDialoghi.BtnColoreClick(Sender: TObject);
begin
  ColorDialog.Color := Memo.Color;
  if ColorDialog.Execute then
    Memo.Color := ColorDialog.Color;
end;

end.
