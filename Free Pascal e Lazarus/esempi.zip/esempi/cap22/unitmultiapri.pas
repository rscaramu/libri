{ UnitMultiApri - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitMultiApri;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ComCtrls,
  Dialogs;

type
  TFormMultiApri = class(TForm)
    PC: TPageControl;
    BtnApri: TButton;
    OpenDialog: TOpenDialog;
    procedure BtnApriClick(Sender: TObject);
  private
    procedure ApriFile(const Percorso: String);
  end;

var
  FormMultiApri: TFormMultiApri;

implementation

{$R *.lfm}

procedure TFormMultiApri.BtnApriClick(Sender: TObject);
var
  F: String;
begin
  OpenDialog.Options := OpenDialog.Options +
    [ofAllowMultiSelect, ofFileMustExist];
  if OpenDialog.Execute then
    for F in OpenDialog.Files do
      ApriFile(F);
end;

procedure TFormMultiApri.ApriFile(const Percorso: String);
var
  Scheda: TTabSheet;
  M: TMemo;
begin
  Scheda := TTabSheet.Create(PC);
  Scheda.PageControl := PC;
  Scheda.Caption := ExtractFileName(Percorso);
  Scheda.Hint := Percorso;
  M := TMemo.Create(Scheda);
  M.Parent := Scheda;
  M.Align := alClient;
  M.ScrollBars := ssAutoBoth;
  M.Lines.LoadFromFile(Percorso);
  PC.ActivePage := Scheda;
end;

end.
