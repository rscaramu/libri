{ UnitTastiera - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitTastiera;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, LCLType;

type
  TFormTastiera = class(TForm)
    EdtUno: TEdit;
    EdtDue: TEdit;
    LblStato: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
                          Shift: TShiftState);
  private
    FAggiornamenti: Integer;
  end;

var
  FormTastiera: TFormTastiera;

implementation

{$R *.lfm}

procedure TFormTastiera.FormCreate(Sender: TObject);
begin
  KeyPreview := True;
end;

procedure TFormTastiera.FormKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  case Key of
    VK_F5:
      begin
        Inc(FAggiornamenti);
        LblStato.Caption := Format('Aggiornato %d volte',
                                   [FAggiornamenti]);
        Key := 0;
      end;
    VK_ESCAPE:
      if ActiveControl is TEdit then
      begin
        TEdit(ActiveControl).Clear;
        Key := 0;
      end;
  end;
end;

end.
