{ UnitBuffer - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitBuffer;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls;

type
  TFormBuffer = class(TForm)
    PaintBox: TPaintBox;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure PaintBoxPaint(Sender: TObject);
    procedure PaintBoxResize(Sender: TObject);
  private
    FBmp: TBitmap;
    procedure Ridisegna;
  end;

var
  FormBuffer: TFormBuffer;

implementation

{$R *.lfm}

procedure TFormBuffer.FormCreate(Sender: TObject);
begin
  FBmp := TBitmap.Create;
  Ridisegna;
end;

procedure TFormBuffer.FormDestroy(Sender: TObject);
begin
  FBmp.Free;
end;

procedure TFormBuffer.Ridisegna;
var
  X, Y: Integer;
begin
  FBmp.SetSize(PaintBox.Width, PaintBox.Height);
  FBmp.Canvas.Brush.Color := clBlack;
  FBmp.Canvas.FillRect(0, 0, FBmp.Width, FBmp.Height);
  for Y := 0 to FBmp.Height - 1 do
    for X := 0 to FBmp.Width - 1 do
      if (X * X + Y * Y) mod 97 < 30 then
        FBmp.Canvas.Pixels[X, Y] := clLime;
  PaintBox.Invalidate;
end;

procedure TFormBuffer.PaintBoxResize(Sender: TObject);
begin
  Ridisegna;
end;

procedure TFormBuffer.PaintBoxPaint(Sender: TObject);
begin
  PaintBox.Canvas.Draw(0, 0, FBmp);
end;

end.
