{ UnitDisegno - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitDisegno;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls;

type
  TFormDisegno = class(TForm)
    PaintBox: TPaintBox;
    procedure PaintBoxPaint(Sender: TObject);
    procedure PaintBoxMouseDown(Sender: TObject;
      Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
  private
    FPunti: array of TPoint;
  end;

var
  FormDisegno: TFormDisegno;

implementation

{$R *.lfm}

procedure TFormDisegno.PaintBoxPaint(Sender: TObject);
var
  C: TCanvas;
  I: Integer;
begin
  C := PaintBox.Canvas;
  C.Brush.Color := clWhite;
  C.FillRect(0, 0, PaintBox.Width, PaintBox.Height);
  C.Pen.Color := clSilver;
  for I := 0 to PaintBox.Width div 20 do
    C.Line(I * 20, 0, I * 20, PaintBox.Height);
  for I := 0 to PaintBox.Height div 20 do
    C.Line(0, I * 20, PaintBox.Width, I * 20);
  C.Pen.Color := clBlue;
  C.Pen.Width := 2;
  if Length(FPunti) > 1 then
    C.Polyline(FPunti);
  C.Brush.Color := clRed;
  C.Pen.Color := clMaroon;
  C.Pen.Width := 1;
  for I := 0 to High(FPunti) do
    C.Ellipse(FPunti[I].X - 4, FPunti[I].Y - 4,
              FPunti[I].X + 4, FPunti[I].Y + 4);
  C.Font.Size := 9;
  C.Brush.Style := bsClear;
  C.TextOut(4, 4, Format('%d punti', [Length(FPunti)]));
end;

procedure TFormDisegno.PaintBoxMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  if Button = mbLeft then
  begin
    SetLength(FPunti, Length(FPunti) + 1);
    FPunti[High(FPunti)] := Point(X, Y);
  end
  else
    FPunti := nil;
  PaintBox.Invalidate;
end;

end.
