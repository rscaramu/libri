{ UnitGrafico - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitGrafico;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls;

type
  TFormGrafico = class(TForm)
    PaintBox: TPaintBox;
    procedure FormCreate(Sender: TObject);
    procedure PaintBoxPaint(Sender: TObject);
  private
    FValori: array of Double;
    FMin, FMax: Double;
    function PX(I: Integer): Integer;
    function PY(V: Double): Integer;
  end;

var
  FormGrafico: TFormGrafico;

implementation

{$R *.lfm}

const
  Margine = 30;

procedure TFormGrafico.FormCreate(Sender: TObject);
var
  I: Integer;
begin
  SetLength(FValori, 24);
  FMin := 1E9;
  FMax := -1E9;
  for I := 0 to 23 do
  begin
    FValori[I] := 15 + 10 * Sin(I / 24 * 2 * Pi);
    if FValori[I] < FMin then FMin := FValori[I];
    if FValori[I] > FMax then FMax := FValori[I];
  end;
end;

function TFormGrafico.PX(I: Integer): Integer;
begin
  Result := Margine + Round(I / High(FValori) *
                            (PaintBox.Width - 2 * Margine));
end;

function TFormGrafico.PY(V: Double): Integer;
begin
  Result := PaintBox.Height - Margine -
            Round((V - FMin) / (FMax - FMin) *
                  (PaintBox.Height - 2 * Margine));
end;

procedure TFormGrafico.PaintBoxPaint(Sender: TObject);
var
  C: TCanvas;
  I: Integer;
begin
  C := PaintBox.Canvas;
  C.Brush.Color := clWhite;
  C.FillRect(PaintBox.ClientRect);
  C.Pen.Color := clGray;
  C.Line(PX(0), PY(FMin), PX(High(FValori)), PY(FMin));
  C.Line(PX(0), PY(FMin), PX(0), PY(FMax));
  C.Brush.Style := bsClear;
  C.TextOut(2, PY(FMax) - 6, Format('%.0f', [FMax]));
  C.TextOut(2, PY(FMin) - 6, Format('%.0f', [FMin]));
  C.Pen.Color := clNavy;
  C.Pen.Width := 2;
  C.MoveTo(PX(0), PY(FValori[0]));
  for I := 1 to High(FValori) do
    C.LineTo(PX(I), PY(FValori[I]));
  for I := 0 to High(FValori) do
    if I mod 6 = 0 then
      C.TextOut(PX(I) - 6, PaintBox.Height - Margine + 4,
                IntToStr(I) + 'h');
end;

end.
