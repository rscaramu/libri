{ UnitImmagine - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitImmagine;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls,
  StdCtrls, Dialogs;

type
  TFormImmagine = class(TForm)
    Image: TImage;
    BtnCarica: TButton;
    BtnSalva: TButton;
    BtnGenera: TButton;
    OpenPicture: TOpenDialog;
    procedure BtnCaricaClick(Sender: TObject);
    procedure BtnGeneraClick(Sender: TObject);
    procedure BtnSalvaClick(Sender: TObject);
  end;

var
  FormImmagine: TFormImmagine;

implementation

{$R *.lfm}

procedure TFormImmagine.BtnCaricaClick(Sender: TObject);
begin
  OpenPicture.Filter := 'Immagini|*.png;*.jpg;*.bmp';
  if OpenPicture.Execute then
  begin
    Image.Picture.LoadFromFile(OpenPicture.FileName);
    Caption := Format('%dx%d', [Image.Picture.Width,
                                Image.Picture.Height]);
  end;
end;

procedure TFormImmagine.BtnGeneraClick(Sender: TObject);
var
  I: Integer;
begin
  Image.Picture.Bitmap.SetSize(256, 256);
  with Image.Picture.Bitmap.Canvas do
  begin
    Brush.Color := clWhite;
    FillRect(0, 0, 256, 256);
    for I := 0 to 15 do
    begin
      Pen.Color := RGBToColor(I * 16, 0, 255 - I * 16);
      Ellipse(I * 8, I * 8, 256 - I * 8, 256 - I * 8);
    end;
  end;
  Image.Invalidate;
end;

procedure TFormImmagine.BtnSalvaClick(Sender: TObject);
var
  Png: TPortableNetworkGraphic;
begin
  Png := TPortableNetworkGraphic.Create;
  try
    Png.Assign(Image.Picture.Bitmap);
    Png.SaveToFile('cerchi.png');
  finally
    Png.Free;
  end;
end;

end.
