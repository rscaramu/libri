{ UnitIstogramma - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitIstogramma;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls,
  StdCtrls;

type
  TFormIstogramma = class(TForm)
    PaintBox: TPaintBox;
    BtnNuovi: TButton;
    procedure BtnNuoviClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure PaintBoxPaint(Sender: TObject);
    procedure PaintBoxResize(Sender: TObject);
  private
    FBmp: TBitmap;
    FValori: array[0..9] of Integer;
    procedure Aggiorna;
  end;

var
  FormIstogramma: TFormIstogramma;

implementation

{$R *.lfm}

procedure TFormIstogramma.FormCreate(Sender: TObject);
begin
  FBmp := TBitmap.Create;
  Randomize;
  BtnNuoviClick(nil);
end;

procedure TFormIstogramma.FormDestroy(Sender: TObject);
begin
  FBmp.Free;
end;

procedure TFormIstogramma.BtnNuoviClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 0 to 9 do
    FValori[I] := Random(90) + 10;
  Aggiorna;
end;

procedure TFormIstogramma.Aggiorna;
var
  I, W, H, Larg: Integer;
  C: TCanvas;
begin
  W := PaintBox.Width;
  H := PaintBox.Height;
  if (W = 0) or (H = 0) then
    Exit;
  FBmp.SetSize(W, H);
  C := FBmp.Canvas;
  C.Brush.Color := clWhite;
  C.FillRect(0, 0, W, H);
  Larg := W div 10;
  for I := 0 to 9 do
  begin
    if Odd(I) then
      C.Brush.Color := clSkyBlue
    else
      C.Brush.Color := clNavy;
    C.Rectangle(I * Larg + 4,
                H - 20 - FValori[I] * (H - 40) div 100,
                (I + 1) * Larg - 4, H - 20);
    C.Brush.Style := bsClear;
    C.TextOut(I * Larg + 8, H - 18, IntToStr(FValori[I]));
    C.Brush.Style := bsSolid;
  end;
  PaintBox.Invalidate;
end;

procedure TFormIstogramma.PaintBoxResize(Sender: TObject);
begin
  Aggiorna;
end;

procedure TFormIstogramma.PaintBoxPaint(Sender: TObject);
begin
  PaintBox.Canvas.Draw(0, 0, FBmp);
end;

end.
