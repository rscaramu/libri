{ UnitManoLibera - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitManoLibera;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls,
  StdCtrls, Spin, Dialogs;

type
  TFormManoLibera = class(TForm)
    Image: TImage;
    BtnPulisci: TButton;
    BtnColore: TColorButton;
    SpnSpessore: TSpinEdit;
    procedure BtnPulisciClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ImageMouseDown(Sender: TObject;
      Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure ImageMouseMove(Sender: TObject;
      Shift: TShiftState; X, Y: Integer);
  private
    FDisegnando: Boolean;
  end;

var
  FormManoLibera: TFormManoLibera;

implementation

{$R *.lfm}

procedure TFormManoLibera.FormCreate(Sender: TObject);
begin
  Image.Picture.Bitmap.SetSize(Image.Width, Image.Height);
  BtnPulisciClick(nil);
end;

procedure TFormManoLibera.BtnPulisciClick(Sender: TObject);
begin
  with Image.Picture.Bitmap.Canvas do
  begin
    Brush.Color := clWhite;
    FillRect(0, 0, Image.Width, Image.Height);
  end;
  Image.Invalidate;
end;

procedure TFormManoLibera.ImageMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  FDisegnando := Button = mbLeft;
  with Image.Picture.Bitmap.Canvas do
  begin
    Pen.Color := BtnColore.ButtonColor;
    Pen.Width := SpnSpessore.Value;
    MoveTo(X, Y);
  end;
end;

procedure TFormManoLibera.ImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  if FDisegnando and (ssLeft in Shift) then
  begin
    Image.Picture.Bitmap.Canvas.LineTo(X, Y);
    Image.Invalidate;
  end
  else
    FDisegnando := False;
end;

end.
