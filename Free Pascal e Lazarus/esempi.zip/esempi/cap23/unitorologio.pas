{ UnitOrologio - Manuale completo di Free Pascal e Lazarus }
{ Unit LCL: va inserita in un progetto Lazarus e richiede il file .lfm del form }
unit UnitOrologio;
{$mode objfpc}{$H+}
interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, ExtCtrls;

type
  TFormOrologio = class(TForm)
    PaintBox: TPaintBox;
    Timer: TTimer;
    procedure PaintBoxPaint(Sender: TObject);
    procedure TimerTimer(Sender: TObject);
  private
    procedure Lancetta(C: TCanvas; CX, CY: Integer;
                       Angolo, Lunghezza: Double;
                       Spessore: Integer; Colore: TColor);
  end;

var
  FormOrologio: TFormOrologio;

implementation

{$R *.lfm}

procedure TFormOrologio.Lancetta(C: TCanvas; CX, CY: Integer;
  Angolo, Lunghezza: Double; Spessore: Integer;
  Colore: TColor);
begin
  C.Pen.Color := Colore;
  C.Pen.Width := Spessore;
  C.Line(CX, CY,
         CX + Round(Lunghezza * Sin(Angolo)),
         CY - Round(Lunghezza * Cos(Angolo)));
end;

procedure TFormOrologio.PaintBoxPaint(Sender: TObject);
var
  C: TCanvas;
  CX, CY, R, I: Integer;
  H, M, S, MS: Word;
begin
  C := PaintBox.Canvas;
  CX := PaintBox.Width div 2;
  CY := PaintBox.Height div 2;
  if CX < CY then R := CX - 10 else R := CY - 10;
  C.Brush.Color := clWhite;
  C.FillRect(PaintBox.ClientRect);
  C.Pen.Color := clBlack;
  C.Pen.Width := 2;
  C.Ellipse(CX - R, CY - R, CX + R, CY + R);
  for I := 0 to 11 do
    Lancetta(C, CX + Round((R - 8) * Sin(I * Pi / 6)),
             CY - Round((R - 8) * Cos(I * Pi / 6)),
             I * Pi / 6, 8, 2, clBlack);
  DecodeTime(Now, H, M, S, MS);
  Lancetta(C, CX, CY, (H mod 12 + M / 60) * Pi / 6,
           R * 0.5, 4, clBlack);
  Lancetta(C, CX, CY, (M + S / 60) * Pi / 30,
           R * 0.75, 3, clBlack);
  Lancetta(C, CX, CY, S * Pi / 30, R * 0.9, 1, clRed);
end;

procedure TFormOrologio.TimerTimer(Sender: TObject);
begin
  PaintBox.Invalidate;
end;

end.
