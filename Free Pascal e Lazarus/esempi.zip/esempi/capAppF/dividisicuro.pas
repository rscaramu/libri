{ DividiSicuro - Manuale completo di Free Pascal e Lazarus }
program DividiSicuro;
{$mode objfpc}{$H+}
uses
  SysUtils;
type
  EDivisoreNullo = class(Exception);

function DividiSicuro(A, B: Double): Double;
begin
  if B = 0 then
    raise EDivisoreNullo.CreateFmt(
      'Divisione di %g per zero', [A]);
  Result := A / B;
end;

begin
  WriteLn(DividiSicuro(10, 4):0:2);
  try
    WriteLn(DividiSicuro(3, 0):0:2);
  except
    on E: EDivisoreNullo do
      WriteLn(E.Message);
  end;
end.
