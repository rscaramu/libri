{ ElencoData - Manuale completo di Free Pascal e Lazarus }
program ElencoData;
{$mode objfpc}{$H+}
uses
  SysUtils;
var
  SR: TSearchRec;
  Dir: String;
begin
  Dir := IncludeTrailingPathDelimiter(GetCurrentDir);
  if FindFirst(Dir + '*.txt', faAnyFile, SR) = 0 then
  begin
    repeat
      if (SR.Attr and faDirectory) = 0 then
        WriteLn(SR.Name:16, SR.Size:8, '  ',
                FormatDateTime('yyyy-mm-dd',
                  FileDateToDateTime(SR.Time)));
    until FindNext(SR) <> 0;
    FindClose(SR);
  end;
end.
