{ Fibonacci - Manuale completo di Free Pascal e Lazarus }
program Fibonacci;
{$mode objfpc}{$H+}
var
  A, B, T: Integer;
begin
  A := 0;
  B := 1;
  while B <= 1000 do
  begin
    Write(B, ' ');
    T := A + B;
    A := B;
    B := T;
  end;
  WriteLn(B);
end.
