{ FibRicorsivo - Manuale completo di Free Pascal e Lazarus }
program FibRicorsivo;
{$mode objfpc}{$H+}
var
  Chiamate: Int64 = 0;

function FibR(N: Integer): Int64;
begin
  Inc(Chiamate);
  if N < 2 then
    Result := N
  else
    Result := FibR(N - 1) + FibR(N - 2);
end;

function FibI(N: Integer): Int64;
var
  I: Integer;
  A, B, T: Int64;
begin
  A := 0;
  B := 1;
  for I := 1 to N do
  begin
    T := A + B;
    A := B;
    B := T;
  end;
  Result := A;
end;

begin
  WriteLn(FibR(25), ' con ', Chiamate, ' chiamate');
  WriteLn(FibI(25), ' iterativo');
end.
