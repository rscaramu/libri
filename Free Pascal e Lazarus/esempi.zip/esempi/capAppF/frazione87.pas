{ Frazione87 - Manuale completo di Free Pascal e Lazarus }
program Frazione87;
{$mode objfpc}{$H+}
{$modeswitch advancedrecords}
uses
  SysUtils;
type
  TFrazione = record
    N, D: Integer;
    function Somma(const F: TFrazione): TFrazione;
    procedure Semplifica;
    function ToString: String;
  end;

function MCD(A, B: Integer): Integer;
begin
  if B = 0 then
    Result := Abs(A)
  else
    Result := MCD(B, A mod B);
end;

function TFrazione.Somma(const F: TFrazione): TFrazione;
begin
  Result.N := N * F.D + F.N * D;
  Result.D := D * F.D;
  Result.Semplifica;
end;

procedure TFrazione.Semplifica;
var
  G: Integer;
begin
  G := MCD(N, D);
  if G > 1 then
  begin
    N := N div G;
    D := D div G;
  end;
end;

function TFrazione.ToString: String;
begin
  Result := Format('%d/%d', [N, D]);
end;

var
  A, B: TFrazione;
begin
  A.N := 1; A.D := 6;
  B.N := 1; B.D := 3;
  WriteLn(A.Somma(B).ToString);
end.
