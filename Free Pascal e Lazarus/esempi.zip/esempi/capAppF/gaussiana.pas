{ Gaussiana - Manuale completo di Free Pascal e Lazarus }
program Gaussiana;
{$mode objfpc}{$H+}
uses
  Math;
var
  A: array[0..999] of Double;
  I: Integer;
begin
  RandSeed := 1;
  for I := 0 to 999 do
    A[I] := RandG(100, 15);
  WriteLn('Media vicina a 100? ', Abs(Mean(A) - 100) < 2);
  WriteLn('Deviazione vicina a 15? ',
          Abs(StdDev(A) - 15) < 2);
end.
