{ GiorniMese - Manuale completo di Free Pascal e Lazarus }
program GiorniMese;
{$mode objfpc}{$H+}
type
  TMese = (Gen, Feb, Mar, Apr, Mag, Giu, Lug, Ago, Sett, Ott,
           Nov, Dic);

function Bisestile(Anno: Integer): Boolean;
begin
  Result := ((Anno mod 4 = 0) and (Anno mod 100 <> 0)) or
            (Anno mod 400 = 0);
end;

function GiorniDelMese(M: TMese; Anno: Integer): Integer;
begin
  case M of
    Apr, Giu, Sett, Nov: Result := 30;
    Feb: if Bisestile(Anno) then
           Result := 29
         else
           Result := 28;
  else
    Result := 31;
  end;
end;

begin
  WriteLn(GiorniDelMese(Feb, 2024), ' ',
          GiorniDelMese(Feb, 2026), ' ',
          GiorniDelMese(Sett, 2026));
end.
