{ Hash188 - Manuale completo di Free Pascal e Lazarus }
program Hash188;
{$mode objfpc}{$H+}
uses
  SysUtils;

function Hash(const S: String): LongWord;
var
  C: Char;
begin
  Result := 7;
  {$PUSH}{$Q-}{$R-}
  for C in S do
    Result := Result * 31 + Ord(C);
  {$POP}
end;

function HashControllato(const S: String): LongWord;
var
  C: Char;
begin
  Result := 7;
  {$PUSH}{$Q+}{$R+}
  for C in S do
    Result := Result * 31 + Ord(C);
  {$POP}
end;

begin
  WriteLn(Hash('Free Pascal e Lazarus'));
  try
    WriteLn(HashControllato('Free Pascal e Lazarus'));
  except
    on E: Exception do
      WriteLn(E.ClassName);
  end;
end.
