{ HelperLista - Manuale completo di Free Pascal e Lazarus }
program HelperLista;
{$mode objfpc}{$H+}
uses
  Classes, SysUtils;
type
  TStringListHelper = class helper for TStringList
    function ContaOccorrenze(const S: String): Integer;
    procedure RimuoviVuote;
  end;

function TStringListHelper.ContaOccorrenze(const S: String):
  Integer;
var
  R: String;
begin
  Result := 0;
  for R in Self do
    if R = S then
      Inc(Result);
end;

procedure TStringListHelper.RimuoviVuote;
var
  I: Integer;
begin
  for I := Count - 1 downto 0 do
    if Trim(Strings[I]) = '' then
      Delete(I);
end;

var
  L: TStringList;
begin
  L := TStringList.Create;
  try
    L.CommaText := 'a,,b,a,  ,c';
    L.RimuoviVuote;
    WriteLn(L.CommaText, ' ', L.ContaOccorrenze('a'));
  finally
    L.Free;
  end;
end.
