{ Indovina - Manuale completo di Free Pascal e Lazarus }
{ Input di prova (una voce per riga):  50 | 25 | 12 | 6 | 9 | 8 }
program Indovina;
{$mode objfpc}{$H+}
var
  Segreto, Tentativo, N: Integer;
begin
  RandSeed := 7;
  Segreto := Random(100) + 1;
  N := 0;
  repeat
    ReadLn(Tentativo);
    Inc(N);
    if Tentativo < Segreto then
      WriteLn('troppo basso')
    else if Tentativo > Segreto then
      WriteLn('troppo alto');
  until Tentativo = Segreto;
  WriteLn('Indovinato in ', N, ' tentativi');
end.
