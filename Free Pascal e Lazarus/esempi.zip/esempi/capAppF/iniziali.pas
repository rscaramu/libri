{ Iniziali - Manuale completo di Free Pascal e Lazarus }
program Iniziali;
{$mode objfpc}{$H+}
uses
  SysUtils;

function Capitalizza(const S: String): String;
var
  I: Integer;
  Inizio: Boolean;
begin
  Result := LowerCase(S);
  Inizio := True;
  for I := 1 to Length(Result) do
    if Result[I] = ' ' then
      Inizio := True
    else if Inizio then
    begin
      Result[I] := UpCase(Result[I]);
      Inizio := False;
    end;
end;

begin
  WriteLn(Capitalizza('free pascal e LAZARUS'));
end.
