{ Inverso176 - Manuale completo di Free Pascal e Lazarus }
program Inverso176;
{$mode objfpc}{$H+}
uses
  Classes, SysUtils;
var
  M: TMemoryStream;
  I: Integer;
  D: Double;
begin
  M := TMemoryStream.Create;
  try
    for I := 1 to 10 do
    begin
      D := I * 1.5;
      M.WriteBuffer(D, SizeOf(D));
    end;
    for I := 9 downto 7 do
    begin
      M.Seek(I * SizeOf(Double), soBeginning);
      M.ReadBuffer(D, SizeOf(D));
      Write(D:0:1, ' ');
    end;
    WriteLn;
  finally
    M.Free;
  end;
end.
