{ Istanze - Manuale completo di Free Pascal e Lazarus }
program Istanze;
{$mode objfpc}{$H+}
type
  TContata = class
  private
    class var FVive: Integer;
  public
    constructor Create;
    destructor Destroy; override;
    class property Vive: Integer read FVive;
  end;

constructor TContata.Create;
begin
  Inc(FVive);
end;

destructor TContata.Destroy;
begin
  Dec(FVive);
  inherited;
end;

var
  A, B: TContata;
begin
  WriteLn('Prima: ', TContata.Vive);
  A := TContata.Create;
  B := TContata.Create;
  try
    WriteLn('Dentro: ', TContata.Vive);
  finally
    A.Free;
    B.Free;
  end;
  WriteLn('Dopo: ', TContata.Vive);
end.
