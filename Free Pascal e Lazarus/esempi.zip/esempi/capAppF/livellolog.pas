{ LivelloLog - Manuale completo di Free Pascal e Lazarus }
program LivelloLog;
{$mode objfpc}{$H+}
uses
  SysUtils, TypInfo;
type
  TLivelloLog = (llDebug, llInfo, llAvviso, llErrore);
var
  L: TLivelloLog;
  S: String;
  N: Integer;
begin
  L := llAvviso;
  S := GetEnumName(TypeInfo(TLivelloLog), Ord(L));
  WriteLn('livello=', S);
  N := GetEnumValue(TypeInfo(TLivelloLog), 'llErrore');
  if N >= 0 then
    WriteLn('Letto: ', TLivelloLog(N) = llErrore);
  WriteLn('Sconosciuto: ',
          GetEnumValue(TypeInfo(TLivelloLog), 'llBoh'));
end.
