{ LowHigh - Manuale completo di Free Pascal e Lazarus }
program LowHigh;
{$mode objfpc}{$H+}
begin
  WriteLn('ShortInt ', Low(ShortInt), ' ', High(ShortInt));
  WriteLn('Byte     ', Low(Byte), ' ', High(Byte));
  WriteLn('SmallInt ', Low(SmallInt), ' ', High(SmallInt));
  WriteLn('Word     ', Low(Word), ' ', High(Word));
  WriteLn('LongInt  ', Low(LongInt), ' ', High(LongInt));
  WriteLn('LongWord ', Low(LongWord), ' ', High(LongWord));
end.
