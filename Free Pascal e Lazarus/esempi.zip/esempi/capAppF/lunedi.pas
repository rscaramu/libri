{ Lunedi - Manuale completo di Free Pascal e Lazarus }
program Lunedi;
{$mode objfpc}{$H+}
uses
  SysUtils, DateUtils;

function LunediDelMese(Anno, Mese: Integer): Integer;
var
  D: TDateTime;
begin
  Result := 0;
  D := EncodeDate(Anno, Mese, 1);
  while MonthOf(D) = Mese do
  begin
    if DayOfTheWeek(D) = 1 then
      Inc(Result);
    D := D + 1;
  end;
end;

begin
  WriteLn(LunediDelMese(2026, 9), ' ',
          LunediDelMese(2026, 2));
end.
