{ Maiuscolo - Manuale completo di Free Pascal e Lazarus }
program Maiuscolo;
{$mode objfpc}{$H+}
uses
  SysUtils;
var
  Fin, Fout: TextFile;
  Riga: String;
begin
  AssignFile(Fout, 'orig.txt');
  Rewrite(Fout);
  WriteLn(Fout, 'prima riga');
  WriteLn(Fout, 'seconda');
  CloseFile(Fout);
  AssignFile(Fin, 'orig.txt');
  AssignFile(Fout, 'maiusc.txt');
  Reset(Fin);
  Rewrite(Fout);
  while not EOF(Fin) do
  begin
    ReadLn(Fin, Riga);
    WriteLn(Fout, UpperCase(Riga));
  end;
  CloseFile(Fin);
  CloseFile(Fout);
  Reset(Fout);
  while not EOF(Fout) do
  begin
    ReadLn(Fout, Riga);
    WriteLn(Riga);
  end;
  CloseFile(Fout);
end.
