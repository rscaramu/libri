{ MassimoGenerico - Manuale completo di Free Pascal e Lazarus }
program MassimoGenerico;
{$mode objfpc}{$H+}
uses
  SysUtils, Generics.Defaults;

generic function Massimo<T>(const A: array of T;
  Comp: specialize IComparer<T>): T;
var
  I: Integer;
begin
  Result := A[0];
  for I := 1 to High(A) do
    if Comp.Compare(A[I], Result) > 0 then
      Result := A[I];
end;

begin
  WriteLn(specialize Massimo<Integer>([3, 9, 2],
          specialize TComparer<Integer>.Default));
  WriteLn(specialize Massimo<String>(
          ['pera', 'zucca', 'mela'],
          specialize TComparer<String>.Default));
end.
