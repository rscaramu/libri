{ Matrice - Manuale completo di Free Pascal e Lazarus }
program Matrice;
{$mode objfpc}{$H+}
const
  M: array[0..2, 0..2] of Integer = ((1, 2, 3), (4, 5, 6),
                                     (7, 8, 9));
var
  R, C, S, D1, D2: Integer;
begin
  D1 := 0;
  D2 := 0;
  for R := 0 to 2 do
  begin
    S := 0;
    for C := 0 to 2 do
      S := S + M[R, C];
    WriteLn('Riga ', R, ': ', S);
    D1 := D1 + M[R, R];
    D2 := D2 + M[R, 2 - R];
  end;
  for C := 0 to 2 do
  begin
    S := 0;
    for R := 0 to 2 do
      S := S + M[R, C];
    WriteLn('Colonna ', C, ': ', S);
  end;
  WriteLn('Diagonali: ', D1, ' ', D2);
end.
