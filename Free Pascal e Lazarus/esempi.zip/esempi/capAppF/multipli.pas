{ Multipli - Manuale completo di Free Pascal e Lazarus }
program Multipli;
{$mode objfpc}{$H+}
var
  I, N: Integer;
begin
  for I := 1 to 100 do
    if I mod 7 = 0 then
      Write(I, ' ');
  WriteLn;
  N := 7;
  while N <= 100 do
  begin
    Write(N, ' ');
    N := N + 7;
  end;
  WriteLn;
end.
