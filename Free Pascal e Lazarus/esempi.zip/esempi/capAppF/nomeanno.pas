{ NomeAnno - Manuale completo di Free Pascal e Lazarus }
program NomeAnno;
{$mode objfpc}{$H+}
uses
  SysUtils, DateUtils;
begin
  WriteLn('Roberto');
  WriteLn(YearOf(Now));
end.
