{ Ordina3 - Manuale completo di Free Pascal e Lazarus }
program Ordina3;
{$mode objfpc}{$H+}

procedure Ordina(var A, B, C: Integer);

  procedure Scambia(var X, Y: Integer);
  var
    T: Integer;
  begin
    T := X;
    X := Y;
    Y := T;
  end;

begin
  if A > B then Scambia(A, B);
  if B > C then Scambia(B, C);
  if A > B then Scambia(A, B);
end;

var
  X, Y, Z: Integer;
begin
  X := 9; Y := 2; Z := 5;
  Ordina(X, Y, Z);
  WriteLn(X, ' ', Y, ' ', Z);
end.
