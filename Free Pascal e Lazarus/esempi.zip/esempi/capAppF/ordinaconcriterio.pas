{ OrdinaConCriterio - Manuale completo di Free Pascal e Lazarus }
program OrdinaConCriterio;
{$mode objfpc}{$H+}
type
  TConfronto = function(A, B: Integer): Boolean;
  TInteri = array of Integer;

function Crescente(A, B: Integer): Boolean;
begin
  Result := A > B;    { True = vanno scambiati }
end;

function Decrescente(A, B: Integer): Boolean;
begin
  Result := A < B;
end;

procedure Bolle(var A: TInteri; Scambia: TConfronto);
var
  I, J, T: Integer;
begin
  for I := High(A) downto 1 do
    for J := 0 to I - 1 do
      if Scambia(A[J], A[J + 1]) then
      begin
        T := A[J];
        A[J] := A[J + 1];
        A[J + 1] := T;
      end;
end;

procedure Stampa(const A: TInteri);
var
  V: Integer;
begin
  for V in A do
    Write(V, ' ');
  WriteLn;
end;

var
  A: TInteri;
begin
  A := [3, 1, 2];
  Bolle(A, @Crescente);
  Stampa(A);
  Bolle(A, @Decrescente);
  Stampa(A);
end.
