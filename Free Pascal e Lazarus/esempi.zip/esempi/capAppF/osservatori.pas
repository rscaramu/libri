{ Osservatori - Manuale completo di Free Pascal e Lazarus }
program Osservatori;
{$mode objfpc}{$H+}
{$interfaces corba}
type
  IOsservatore = interface
    procedure Notifica(const Evento: String);
  end;

  TSoggetto = class
  private
    FOsservatori: array of IOsservatore;
  public
    procedure Aggiungi(O: IOsservatore);
    procedure Avvisa(const Evento: String);
  end;

  TStampa = class(TObject, IOsservatore)
    Prefisso: String;
    procedure Notifica(const Evento: String);
  end;

procedure TSoggetto.Aggiungi(O: IOsservatore);
begin
  SetLength(FOsservatori, Length(FOsservatori) + 1);
  FOsservatori[High(FOsservatori)] := O;
end;

procedure TSoggetto.Avvisa(const Evento: String);
var
  O: IOsservatore;
begin
  for O in FOsservatori do
    O.Notifica(Evento);
end;

procedure TStampa.Notifica(const Evento: String);
begin
  WriteLn(Prefisso, Evento);
end;

var
  S: TSoggetto;
  A, B: TStampa;
begin
  S := TSoggetto.Create;
  A := TStampa.Create;
  B := TStampa.Create;
  try
    A.Prefisso := '[A] ';
    B.Prefisso := '[B] ';
    S.Aggiungi(A);
    S.Aggiungi(B);
    S.Avvisa('avvio');
  finally
    B.Free;
    A.Free;
    S.Free;
  end;
end.
