{ Palindromi - Manuale completo di Free Pascal e Lazarus }
program Palindromi;
{$mode objfpc}{$H+}
uses
  SysUtils;

function EPalindromo(const S: String): Boolean;
var
  T: String;
  I: Integer;
begin
  T := LowerCase(S);
  for I := 1 to Length(T) div 2 do
    if T[I] <> T[Length(T) - I + 1] then
      Exit(False);
  Result := True;
end;

begin
  WriteLn(EPalindromo('Anna'), ' ', EPalindromo('radar'), ' ',
          EPalindromo('Pascal'));
end.
