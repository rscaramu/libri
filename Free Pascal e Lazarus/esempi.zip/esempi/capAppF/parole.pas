{ Parole - Manuale completo di Free Pascal e Lazarus }
{ Input di prova (una voce per riga):  il  Pascal   e chiaro }
program Parole;
{$mode objfpc}{$H+}
uses
  SysUtils;
var
  Riga, Parola: String;
  P: Integer;
begin
  ReadLn(Riga);
  Riga := Trim(Riga) + ' ';
  while Riga <> '' do
  begin
    P := Pos(' ', Riga);
    Parola := Copy(Riga, 1, P - 1);
    Delete(Riga, 1, P);
    Riga := TrimLeft(Riga);
    if Parola <> '' then
      WriteLn(Parola, ' (', Length(Parola), ')');
  end;
end.
