{ PerLunghezza - Manuale completo di Free Pascal e Lazarus }
program PerLunghezza;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, Generics.Collections;
type
  TGruppi = specialize TDictionary<Integer, TStringList>;
const
  Parole: array[0..4] of String =
    ('sole', 'luna', 'mare', 'cielo', 'sale');
var
  D: TGruppi;
  L: TStringList;
  P: String;
  K: Integer;
  Chiavi: TStringList;
begin
  D := TGruppi.Create;
  Chiavi := TStringList.Create;
  try
    for P in Parole do
    begin
      if not D.TryGetValue(Length(P), L) then
      begin
        L := TStringList.Create;
        D.Add(Length(P), L);
      end;
      L.Add(P);
    end;
    for K in D.Keys do
      Chiavi.Add(IntToStr(K));
    Chiavi.Sort;
    for P in Chiavi do
      WriteLn(P, ': ', D[StrToInt(P)].CommaText);
  finally
    for L in D.Values do
      L.Free;
    D.Free;
    Chiavi.Free;
  end;
end.
