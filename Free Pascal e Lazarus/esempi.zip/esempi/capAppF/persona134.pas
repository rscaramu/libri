{ Persona134 - Manuale completo di Free Pascal e Lazarus }
program Persona134;
{$mode objfpc}{$H+}
uses
  SysUtils, DateUtils;
type
  TPersona = class
  private
    FNome, FCognome: String;
    FNascita: TDateTime;
    function GetNomeCompleto: String;
  public
    constructor Create(const ANome, ACognome: String;
                       ANascita: TDateTime);
    function Eta(Oggi: TDateTime): Integer;
    property NomeCompleto: String read GetNomeCompleto;
  end;

constructor TPersona.Create(const ANome, ACognome: String;
                            ANascita: TDateTime);
begin
  FNome := ANome;
  FCognome := ACognome;
  FNascita := ANascita;
end;

function TPersona.GetNomeCompleto: String;
begin
  Result := FNome + ' ' + FCognome;
end;

function TPersona.Eta(Oggi: TDateTime): Integer;
begin
  Result := YearsBetween(Oggi, FNascita);
end;

var
  P: TPersona;
begin
  P := TPersona.Create('Ada', 'Lovelace',
                       EncodeDate(1815, 12, 10));
  try
    WriteLn(P.NomeCompleto, ', ',
            P.Eta(EncodeDate(1852, 11, 27)), ' anni');
  finally
    P.Free;
  end;
end.
