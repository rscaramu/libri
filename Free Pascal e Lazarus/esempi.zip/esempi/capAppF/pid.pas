{ Pid - Manuale completo di Free Pascal e Lazarus }
program Pid;
{$mode objfpc}{$H+}
{$IFDEF UNIX}
function getpid: LongInt; cdecl; external 'c';
{$ELSE}
function GetCurrentProcessId: LongWord; stdcall;
  external 'kernel32';
{$ENDIF}
begin
  {$IFDEF UNIX}
  WriteLn('PID positivo? ', getpid > 0);
  {$ELSE}
  WriteLn('PID positivo? ', GetCurrentProcessId > 0);
  {$ENDIF}
end.
