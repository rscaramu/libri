{ PotenzaDiDue - Manuale completo di Free Pascal e Lazarus }
program PotenzaDiDue;
{$mode objfpc}{$H+}

function EPotenzaDiDue(N: Integer): Boolean;
begin
  Result := (N > 0) and ((N and (N - 1)) = 0);
end;

var
  N: Integer;
begin
  for N in [0, 1, 6, 8, 64, 100] do
    WriteLn(N:4, ' ', EPotenzaDiDue(N));
end.
