{ Pulisci - Manuale completo di Free Pascal e Lazarus }
program Pulisci;
{$mode objfpc}{$H+}
uses
  Classes, SysUtils;
var
  L, U: TStringList;
  S: String;
begin
  L := TStringList.Create;
  U := TStringList.Create;
  try
    L.Text := 'b' + LineEnding + '' + LineEnding + 'a' +
              LineEnding + 'b' + LineEnding + '  ';
    U.Sorted := True;
    U.Duplicates := dupIgnore;
    for S in L do
      if Trim(S) <> '' then
        U.Add(S);
    U.SaveToFile('pulito.txt');
    WriteLn(U.CommaText);
  finally
    U.Free;
    L.Free;
  end;
end.
