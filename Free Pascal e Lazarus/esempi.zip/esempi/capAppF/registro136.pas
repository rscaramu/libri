{ Registro136 - Manuale completo di Free Pascal e Lazarus }
program Registro136;
{$mode objfpc}{$H+}
uses
  SysUtils;
type
  TRegistro = class
  private
    FFile: TextFile;
  public
    constructor Create(const NomeFile: String);
    destructor Destroy; override;
    procedure Scrivi(const Msg: String);
  end;

constructor TRegistro.Create(const NomeFile: String);
begin
  AssignFile(FFile, NomeFile);
  Rewrite(FFile);
end;

destructor TRegistro.Destroy;
begin
  CloseFile(FFile);
  inherited;
end;

procedure TRegistro.Scrivi(const Msg: String);
begin
  WriteLn(FFile, FormatDateTime('hh:nn:ss', Now), ' ', Msg);
end;

var
  R: TRegistro;
  F: TextFile;
  S: String;
begin
  R := TRegistro.Create('reg.log');
  try
    R.Scrivi('avvio');
    R.Scrivi('fine');
  finally
    R.Free;
  end;
  AssignFile(F, 'reg.log');
  Reset(F);
  while not EOF(F) do
  begin
    ReadLn(F, S);
    WriteLn(Copy(S, 10, 99));
  end;
  CloseFile(F);
end.
