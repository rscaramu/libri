{ Secondi - Manuale completo di Free Pascal e Lazarus }
program Secondi;
{$mode objfpc}{$H+}
var
  S: Integer;
begin
  S := 3725;
  WriteLn(S div 3600, ' ore, ', (S mod 3600) div 60,
          ' minuti, ', S mod 60, ' secondi');
end.
