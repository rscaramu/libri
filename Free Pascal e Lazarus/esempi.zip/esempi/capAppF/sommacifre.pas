{ SommaCifre - Manuale completo di Free Pascal e Lazarus }
program SommaCifre;
{$mode objfpc}{$H+}
var
  N, S: Integer;
begin
  N := 2026;
  S := 0;
  repeat
    S := S + N mod 10;
    N := N div 10;
  until N = 0;
  WriteLn(S);
end.
