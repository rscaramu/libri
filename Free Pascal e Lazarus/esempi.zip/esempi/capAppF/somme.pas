{ Somme - Manuale completo di Free Pascal e Lazarus }
program Somme;
{$mode objfpc}{$H+}

function Somma(A, B: Integer): Integer; overload;
begin
  WriteLn('  (due interi)');
  Result := A + B;
end;

function Somma(A, B, C: Integer): Integer; overload;
begin
  WriteLn('  (tre interi)');
  Result := A + B + C;
end;

function Somma(A: Integer; B: Double): Double; overload;
begin
  WriteLn('  (intero e reale)');
  Result := A + B;
end;

begin
  WriteLn(Somma(1, 2));
  WriteLn(Somma(1, 2, 3));
  WriteLn(Somma(1, 2.5):0:1);
end.
