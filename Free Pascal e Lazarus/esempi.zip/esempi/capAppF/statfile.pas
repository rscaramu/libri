{ StatFile - Manuale completo di Free Pascal e Lazarus }
program StatFile;
{$mode objfpc}{$H+}
uses
  SysUtils;
var
  F: TextFile;
  Riga: String;
  N, V, Mn, Mx, Somma, Conta: Integer;
begin
  AssignFile(F, 'numeri.txt');
  Rewrite(F);
  WriteLn(F, '10'); WriteLn(F, 'abc'); WriteLn(F, '30');
  WriteLn(F, ''); WriteLn(F, '-5');
  CloseFile(F);
  Reset(F);
  Conta := 0;
  Somma := 0;
  Mn := High(Integer);
  Mx := Low(Integer);
  while not EOF(F) do
  begin
    ReadLn(F, Riga);
    if TryStrToInt(Trim(Riga), V) then
    begin
      Inc(Conta);
      Somma := Somma + V;
      if V < Mn then Mn := V;
      if V > Mx then Mx := V;
    end;
  end;
  CloseFile(F);
  N := Conta;
  WriteLn('Validi ', N, ', media ', Somma / N:0:2,
          ', min ', Mn, ', max ', Mx);
end.
