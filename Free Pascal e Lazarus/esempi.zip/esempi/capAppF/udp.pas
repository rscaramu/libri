{ Udp - Manuale completo di Free Pascal e Lazarus }
program Udp;
{$mode objfpc}{$H+}
uses
  SysUtils, Sockets;
var
  S, R: LongInt;
  Addr, Da: TSockAddr;
  Msg: String;
  Buf: array[0..255] of Char;
  N: LongInt;
  L: TSockLen;
begin
  R := fpSocket(AF_INET, SOCK_DGRAM, 0);
  FillChar(Addr, SizeOf(Addr), 0);
  Addr.sin_family := AF_INET;
  Addr.sin_port := htons(9098);
  Addr.sin_addr.s_addr := htonl($7F000001);
  fpBind(R, @Addr, SizeOf(Addr));
  S := fpSocket(AF_INET, SOCK_DGRAM, 0);
  Msg := 'ciao udp';
  fpSendTo(S, @Msg[1], Length(Msg), 0, @Addr, SizeOf(Addr));
  L := SizeOf(Da);
  N := fpRecvFrom(R, @Buf, SizeOf(Buf), 0, @Da, @L);
  SetString(Msg, Buf, N);
  WriteLn('Ricevuto: ', Msg);
  CloseSocket(S);
  CloseSocket(R);
end.
