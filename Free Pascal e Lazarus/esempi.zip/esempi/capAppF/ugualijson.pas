{ UgualiJson - Manuale completo di Free Pascal e Lazarus }
program UgualiJson;
{$mode objfpc}{$H+}
uses
  SysUtils, fpjson, jsonparser;

function Uguali(A, B: TJSONData): Boolean;
var
  I: Integer;
  N: String;
  OB: TJSONObject;
begin
  if A.JSONType <> B.JSONType then
    Exit(False);
  case A.JSONType of
    jtObject:
      begin
        if A.Count <> B.Count then
          Exit(False);
        OB := TJSONObject(B);
        for I := 0 to A.Count - 1 do
        begin
          N := TJSONObject(A).Names[I];
          if (OB.IndexOfName(N) < 0) or
             not Uguali(A.Items[I], OB.Elements[N]) then
            Exit(False);
        end;
        Result := True;
      end;
    jtArray:
      begin
        if A.Count <> B.Count then
          Exit(False);
        for I := 0 to A.Count - 1 do
          if not Uguali(A.Items[I], B.Items[I]) then
            Exit(False);
        Result := True;
      end;
    jtNull:
      Result := True;
  else
    Result := A.AsString = B.AsString;
  end;
end;

var
  X, Y, Z: TJSONData;
begin
  X := GetJSON('{"a":1,"b":[1,2],"c":null}');
  Y := GetJSON('{"c":null,"b":[1,2],"a":1}');
  Z := GetJSON('{"a":1,"b":[2,1],"c":null}');
  try
    WriteLn(Uguali(X, Y), ' ', Uguali(X, Z));
  finally
    Z.Free;
    Y.Free;
    X.Free;
  end;
end.
