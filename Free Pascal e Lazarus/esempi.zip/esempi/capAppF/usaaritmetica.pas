{ UsaAritmetica - Manuale completo di Free Pascal e Lazarus }
program UsaAritmetica;
{$mode objfpc}{$H+}
uses
  Aritmetica;
begin
  WriteLn(EPrimo(97), ' ', MCD(48, 18), ' ', Fattoriale(12));
end.
