{ Varianti186 - Manuale completo di Free Pascal e Lazarus }
program Varianti186;
{$mode objfpc}{$H+}
uses
  SysUtils, Variants;

procedure Descrivi(const V: array of Variant);
var
  X: Variant;
begin
  for X in V do
    if VarIsNull(X) then
      WriteLn('Null')
    else if VarIsNumeric(X) then
      WriteLn('numero ', Double(X):0:2)
    else if VarIsStr(X) then
      WriteLn('stringa ', VarToStr(X))
    else
      WriteLn('altro');
end;

begin
  Descrivi([42, 3.5, 'ciao', Null, True]);
end.
