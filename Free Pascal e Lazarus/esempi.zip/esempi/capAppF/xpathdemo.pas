{ XPathDemo - Manuale completo di Free Pascal e Lazarus }
program XPathDemo;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, DOM, XMLRead, XPath;
var
  Doc: TXMLDocument;
  R: TXPathVariable;
  I: Integer;
  S: TStringStream;
begin
  S := TStringStream.Create('<biblioteca>' +
    '<libro id="1" anno="1980">' +
    '<titolo>Libro 1</titolo></libro>' +
    '<libro id="2" anno="1990">' +
    '<titolo>Libro 2</titolo></libro>' +
    '</biblioteca>');
  try
    ReadXMLFile(Doc, S);
  finally
    S.Free;
  end;
  try
    R := EvaluateXPathExpression(
      '//libro[@anno > 1985]/titolo/text()',
      Doc.DocumentElement);
    try
      for I := 0 to R.AsNodeSet.Count - 1 do
        WriteLn(TDOMNode(R.AsNodeSet[I]).NodeValue);
    finally
      R.Free;
    end;
  finally
    Doc.Free;
  end;
end.
